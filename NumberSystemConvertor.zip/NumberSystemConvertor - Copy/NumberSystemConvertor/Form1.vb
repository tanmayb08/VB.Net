﻿Public Class Form1
    Dim n, j, i As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        n = Convert.ToInt32(TextBox1.Text)
        TextBox2.Clear()
        Dim iLoop, one, zero As Integer
        one = 1
        zero = 0
        For iLoop = 7 To 0 Step -1
            If ((1 << iLoop) And n) Then
                TextBox2.Text += one.ToString
            Else
                TextBox2.Text += zero.ToString
            End If
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        n = Convert.ToInt32(TextBox1.Text)
        TextBox2.Clear()
        Dim t(4) As String
        i = 0
        While n > 0
            t(i) = Convert.ToString(n Mod 8)
            n = n / 8
            i = i + 1
        End While
        j = i
        Array.Reverse(t)
        For Each i In t
            TextBox2.Text += i.ToString
        Next


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        n = Int(TextBox1.Text.Trim)
        Dim hexString As String = Nothing
        TextBox2.Clear()
        hexString = Hex(n)
        TextBox2.Text = hexString
    End Sub
End Class